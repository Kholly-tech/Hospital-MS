import './App.css'
import AppRoutes from './utils/AppRoutes'

function App() {

  return (
    <>
    <AppRoutes />
    </>
  )
}

export default App
